"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";

import { EmptyState } from "@/components/shared/empty-state";
import { SkeletonCard } from "@/components/shared/skeleton-card";
import { StatusBadge } from "@/components/shared/status-badge";
import { eventApi } from "@/lib/api/event-api";
import { routes } from "@/lib/constants/routes";
import { isExpiredSessionError } from "@/lib/utils/auth-errors";
import type {
  EventParticipant,
  EventStatus,
  EventSummary,
} from "@/types/event";

import { VerificationPrompt } from "../auth/verification-prompt";

import { DiscoveryToggle } from "./discovery-toggle";
import { ParticipantsList } from "./participants-list";

interface EventDetailScreenProps {
  eventId: string;
  isVerified: boolean;
  currentUserEmail: string;
}

function statusBadgeProps(status: EventStatus) {
  switch (status) {
    case "live":
      return { label: "Live now", tone: "success" as const };
    case "upcoming":
      return { label: "Upcoming", tone: "warning" as const };
    case "ended":
      return { label: "Ended", tone: "neutral" as const };
  }
}

function formatDateRange(startsAt: string, endsAt: string): string {
  const start = new Date(startsAt);
  const end = new Date(endsAt);
  const dateStr = start.toLocaleDateString("en-US", {
    weekday: "long",
    month: "long",
    day: "numeric",
    year: "numeric",
  });
  const startTime = start.toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
  });
  const endTime = end.toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
  });
  return `${dateStr} · ${startTime} – ${endTime}`;
}

// ---------------------------------------------------------------------------
// Stealth shield — shown when discovery is OFF and the event is live
// ---------------------------------------------------------------------------
function StealthShield() {
  return (
    <div className="relative overflow-hidden rounded-3xl border border-dashed border-border">
      {/* Blurred ghost rows to hint at content underneath */}
      <div
        className="pointer-events-none select-none space-y-3 p-4 blur-sm"
        aria-hidden
      >
        {[...Array(3)].map((_, i) => (
          <div key={i} className="h-20 rounded-2xl bg-surface" />
        ))}
      </div>
      {/* Overlay label */}
      <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-bg/70 backdrop-blur-[2px]">
        <div className="flex h-10 w-10 items-center justify-center rounded-full border border-border bg-surface">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="h-5 w-5 text-muted"
          >
            <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94" />
            <path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19" />
            <line x1="1" y1="1" x2="23" y2="23" />
          </svg>
        </div>
        <p className="label-xs text-muted">Stealth Mode</p>
        <p className="px-6 text-center text-xs text-muted">
          Enable your Discovery Signal to see who else is here.
        </p>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// EventDetailScreen
// ---------------------------------------------------------------------------
export function EventDetailScreen({
  eventId,
  isVerified,
  currentUserEmail,
}: EventDetailScreenProps) {
  const router = useRouter();
  const [event, setEvent] = useState<EventSummary | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [participants, setParticipants] = useState<EventParticipant[]>([]);
  const [participantsLoading, setParticipantsLoading] = useState(false);
  const [participantsError, setParticipantsError] = useState<string | null>(
    null,
  );

  const [discoveryToggling, setDiscoveryToggling] = useState(false);
  const [discoveryError, setDiscoveryError] = useState<string | null>(null);

  // Load event
  useEffect(() => {
    let cancelled = false;
    setIsLoading(true);
    setLoadError(null);

    eventApi
      .get(eventId)
      .then((data) => {
        if (!cancelled) setEvent(data);
      })
      .catch((err: unknown) => {
        if (isExpiredSessionError(err)) {
          router.replace(
            `/login?next=${encodeURIComponent(routes.app.eventDetail(eventId))}&reason=expired`,
          );
          router.refresh();
          return;
        }

        if (!cancelled)
          setLoadError(
            err instanceof Error ? err.message : "Unable to load event.",
          );
      })
      .finally(() => {
        if (!cancelled) setIsLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [eventId, router]);

  // Load participants — only called when discovery is ON and event is live
  const loadParticipants = useCallback(() => {
    setParticipantsLoading(true);
    setParticipantsError(null);
    eventApi
      .listParticipants(eventId)
      .then(setParticipants)
      .catch((err: unknown) => {
        if (isExpiredSessionError(err)) {
          router.replace(
            `/login?next=${encodeURIComponent(routes.app.eventDetail(eventId))}&reason=expired`,
          );
          router.refresh();
          return;
        }

        setParticipantsError(
          err instanceof Error ? err.message : "Unable to load participants.",
        );
      })
      .finally(() => setParticipantsLoading(false));
  }, [eventId, router]);

  useEffect(() => {
    if (
      isVerified &&
      event?.status === "live" &&
      event.myParticipation?.discoverable === true
    ) {
      loadParticipants();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [event?.id, isVerified, loadParticipants]);

  // Discovery toggle handler
  async function handleDiscoveryToggle(enable: boolean) {
    if (!event) return;
    setDiscoveryToggling(true);
    setDiscoveryError(null);
    try {
      if (enable) {
        await eventApi.enableDiscovery(eventId);
      } else {
        await eventApi.disableDiscovery(eventId);
      }

      setEvent((prev) =>
        prev
          ? {
              ...prev,
              myParticipation: prev.myParticipation
                ? { ...prev.myParticipation, discoverable: enable }
                : prev.myParticipation,
            }
          : prev,
      );

      if (event.status === "live") {
        if (enable) {
          loadParticipants();
        } else {
          setParticipants([]);
          setParticipantsError(null);
        }
      }
    } catch (err: unknown) {
      if (isExpiredSessionError(err)) {
        router.replace(
          `/login?next=${encodeURIComponent(routes.app.eventDetail(eventId))}&reason=expired`,
        );
        router.refresh();
        return;
      }

      setDiscoveryError(
        err instanceof Error ? err.message : "Could not update discovery.",
      );
    } finally {
      setDiscoveryToggling(false);
    }
  }

  // ── Loading ──────────────────────────────────────────────────────────────
  if (isLoading) {
    return (
      <div className="flex flex-col gap-4">
        <SkeletonCard />
        <SkeletonCard />
      </div>
    );
  }

  if (loadError || !event) {
    return (
      <EmptyState
        title="Could not load event"
        description={loadError ?? "Event not found."}
      />
    );
  }

  const badge = statusBadgeProps(event.status);
  const hasJoined = !!event.myParticipation;
  const isDiscoverable = event.myParticipation?.discoverable ?? false;
  const myPersonaId = event.myParticipation?.personaId ?? "";

  return (
    <div className="flex flex-col gap-5">
      {/* ── Event info card ─────────────────────────────────────────────── */}
      <div className="glass rounded-3xl border border-border bg-surface p-5">
        <div className="space-y-3">
          <div className="flex items-start justify-between gap-3">
            <h2 className="text-lg font-semibold text-foreground">
              {event.name}
            </h2>
            <StatusBadge label={badge.label} tone={badge.tone} />
          </div>

          <p className="font-mono text-sm text-muted">
            {formatDateRange(event.startsAt, event.endsAt)}
          </p>

          {event.location ? (
            <p className="font-mono text-sm text-muted">{event.location}</p>
          ) : null}

          {event.description ? (
            <p className="text-sm text-foreground">{event.description}</p>
          ) : null}
        </div>
      </div>

      {/* ── Not joined ──────────────────────────────────────────────────── */}
      {!hasJoined ? (
        <EmptyState
          title="You have not joined this event"
          description="Use the event access code or link from the organizer to join."
        />
      ) : null}

      {/* ── Discovery Signal card (joined only) ─────────────────────────── */}
      {hasJoined ? (
        <div className="glass rounded-3xl border border-border bg-surface p-5">
          <DiscoveryToggle
            enabled={isDiscoverable}
            onToggle={handleDiscoveryToggle}
            isLoading={discoveryToggling}
            disabled={!isVerified}
          />
          {!isVerified ? (
            <div className="mt-4">
              <VerificationPrompt
                compact
                email={currentUserEmail}
                title="Verify your email before joining event discovery"
                description="Participant visibility and discovery signals stay behind verified accounts to keep event networking trustworthy."
              />
            </div>
          ) : null}
          {discoveryError ? (
            <div className="mt-3 rounded-2xl border border-rose-500/30 bg-rose-500/10 px-4 py-3">
              <p className="font-mono text-sm text-rose-500 dark:text-rose-400">
                {discoveryError}
              </p>
            </div>
          ) : null}
          <div className="mt-3 border-t border-border pt-3">
            <p className="font-mono text-xs text-muted">
              Attending as{" "}
              <span className="font-medium capitalize text-foreground">
                {event.myParticipation?.role ?? "attendee"}
              </span>
            </p>
          </div>
        </div>
      ) : null}

      {/* ── Participants section (live window only, joined only) ─────────── */}
      {hasJoined && event.status === "live" ? (
        <section className="flex flex-col gap-3">
          <h3 className="label-xs text-muted">People here</h3>

          {!isVerified ? (
            <VerificationPrompt
              compact
              email={currentUserEmail}
              title="Verify your email to view participants"
              description="Dotly only reveals discoverable event participants to verified accounts."
            />
          ) : !isDiscoverable ? (
            <StealthShield />
          ) : participantsLoading ? (
            <div className="flex flex-col gap-3">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="skeleton h-20 rounded-3xl" />
              ))}
            </div>
          ) : participantsError ? (
            <EmptyState
              title="Could not load participants"
              description={participantsError}
            />
          ) : participants.length === 0 ? (
            <EmptyState
              title="No one else is broadcasting yet"
              description="You are the first to enable discovery here. Others will appear as they turn on their signal."
            />
          ) : (
            <ParticipantsList
              participants={participants}
              eventId={eventId}
              myPersonaId={myPersonaId}
            />
          )}
        </section>
      ) : null}

      {/* ── Upcoming — discovery window not open yet ─────────────────────── */}
      {hasJoined && event.status === "upcoming" ? (
        <div className="rounded-3xl border border-dashed border-border p-5">
          <p className="text-center font-mono text-xs text-muted">
            Participant discovery opens when the event goes live.
          </p>
        </div>
      ) : null}

      {/* ── Ended ────────────────────────────────────────────────────────── */}
      {hasJoined && event.status === "ended" ? (
        <div className="rounded-3xl border border-dashed border-border p-5">
          <p className="text-center font-mono text-xs text-muted">
            This event has ended. Discovery is closed.
          </p>
        </div>
      ) : null}
    </div>
  );
}
