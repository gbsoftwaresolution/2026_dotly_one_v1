"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

import { PrimaryButton } from "@/components/shared/primary-button";
import { personaApi } from "@/lib/api";
import { isApiError } from "@/lib/api/client";
import {
  personaAccessModeOptions,
  personaTypeOptions,
} from "@/lib/persona/labels";
import type { CreatePersonaInput } from "@/types/persona";

const initialFormState: CreatePersonaInput = {
  type: "professional",
  username: "",
  fullName: "",
  jobTitle: "",
  companyName: "",
  tagline: "",
  accessMode: "request",
};

export function PersonaForm() {
  const router = useRouter();
  const [formState, setFormState] =
    useState<CreatePersonaInput>(initialFormState);
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  function updateField<K extends keyof CreatePersonaInput>(
    key: K,
    value: CreatePersonaInput[K],
  ) {
    setFormState((current) => ({
      ...current,
      [key]: value,
    }));
  }

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setIsSubmitting(true);

    try {
      await personaApi.create({
        ...formState,
        username: formState.username.trim().toLowerCase(),
        fullName: formState.fullName.trim(),
        jobTitle: formState.jobTitle.trim(),
        companyName: formState.companyName.trim(),
        tagline: formState.tagline.trim(),
      });

      router.replace("/app/personas");
      router.refresh();
    } catch (submissionError) {
      if (isApiError(submissionError) && submissionError.status === 401) {
        router.replace("/login?next=/app/personas/create&reason=expired");
        router.refresh();
        return;
      }

      setError(
        isApiError(submissionError)
          ? submissionError.message
          : "Unable to create persona right now. Please try again.",
      );
    } finally {
      setIsSubmitting(false);
    }
  }

  const inputCls =
    "min-h-12 w-full rounded-2xl border border-border bg-surface px-4 text-sm font-normal text-foreground outline-none transition-all placeholder:text-muted/50 focus:border-brandRose focus:ring-2 focus:ring-brandRose/20 dark:focus:border-brandCyan dark:focus:ring-brandCyan/20";

  return (
    <form className="space-y-5" onSubmit={handleSubmit}>
      {/* Identity type + access mode */}
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-1.5">
          <label className="label-xs" htmlFor="persona-type">
            Type
          </label>
          <select
            id="persona-type"
            className={inputCls}
            value={formState.type}
            onChange={(event) =>
              updateField(
                "type",
                event.target.value as CreatePersonaInput["type"],
              )
            }
          >
            {personaTypeOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>

        <div className="space-y-1.5">
          <label className="label-xs" htmlFor="persona-access">
            Access mode
          </label>
          <select
            id="persona-access"
            className={inputCls}
            value={formState.accessMode}
            onChange={(event) =>
              updateField(
                "accessMode",
                event.target.value as CreatePersonaInput["accessMode"],
              )
            }
          >
            {personaAccessModeOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Username */}
      <div className="space-y-1.5">
        <label className="label-xs" htmlFor="persona-username">
          Username
        </label>
        <input
          id="persona-username"
          required
          minLength={3}
          maxLength={30}
          pattern="^[a-z0-9_-]+$"
          className={inputCls}
          placeholder="jane-doe"
          value={formState.username}
          onChange={(event) => updateField("username", event.target.value)}
        />
      </div>

      {/* Full name */}
      <div className="space-y-1.5">
        <label className="label-xs" htmlFor="persona-fullname">
          Full name
        </label>
        <input
          id="persona-fullname"
          required
          minLength={1}
          maxLength={120}
          className={inputCls}
          placeholder="Jane Doe"
          value={formState.fullName}
          onChange={(event) => updateField("fullName", event.target.value)}
        />
      </div>

      {/* Job + Company */}
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-1.5">
          <label className="label-xs" htmlFor="persona-jobtitle">
            Job title
          </label>
          <input
            id="persona-jobtitle"
            required
            minLength={1}
            maxLength={120}
            className={inputCls}
            placeholder="Product designer"
            value={formState.jobTitle}
            onChange={(event) => updateField("jobTitle", event.target.value)}
          />
        </div>

        <div className="space-y-1.5">
          <label className="label-xs" htmlFor="persona-company">
            Company
          </label>
          <input
            id="persona-company"
            required
            minLength={1}
            maxLength={120}
            className={inputCls}
            placeholder="Dotly"
            value={formState.companyName}
            onChange={(event) => updateField("companyName", event.target.value)}
          />
        </div>
      </div>

      {/* Tagline */}
      <div className="space-y-1.5">
        <label className="label-xs" htmlFor="persona-tagline">
          Tagline
        </label>
        <textarea
          id="persona-tagline"
          required
          minLength={1}
          maxLength={160}
          rows={4}
          className="w-full rounded-2xl border border-border bg-surface px-4 py-3 text-sm font-normal text-foreground outline-none transition-all placeholder:text-muted/50 focus:border-brandRose focus:ring-2 focus:ring-brandRose/20 dark:focus:border-brandCyan dark:focus:ring-brandCyan/20 resize-none"
          placeholder="Designing thoughtful identity experiences for modern teams."
          value={formState.tagline}
          onChange={(event) => updateField("tagline", event.target.value)}
        />
      </div>

      {error ? (
        <div className="rounded-2xl border border-rose-500/30 bg-rose-500/10 px-4 py-3">
          <p className="font-mono text-sm text-rose-500 dark:text-rose-400">
            {error}
          </p>
        </div>
      ) : null}

      <PrimaryButton type="submit" className="w-full" disabled={isSubmitting}>
        {isSubmitting ? "Creating persona..." : "Create persona"}
      </PrimaryButton>
    </form>
  );
}
